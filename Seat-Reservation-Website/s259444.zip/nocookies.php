<!DOCTYPE html>

<html lang="it">
    <head>
    <meta content="text/html; charset=utf-8" http-equiv="content-type">
    <link href="style.css" rel=stylesheet type="text/css">
    <title> Login </title>
    </head>
    <body>
            </div>
            <p>Sito non navigabile senza cookies abilitati</p>
            <p>Abilita i cookies e poi torna alla Home</p>
            <div>
                <form action="index.php" method="get">
                    <div><button type="submit" class="">Ritorna alla Home</button></div>
                </form>
            </div>
        </div>
    </body>
</html>